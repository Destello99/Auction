package com.project.customer.config;

public class AppConstants {
    public static final int ROLE_ADMIN = 100;
    public static final int NORMAL_USER = 200;
}
