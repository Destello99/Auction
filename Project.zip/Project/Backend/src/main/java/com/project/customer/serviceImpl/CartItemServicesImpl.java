package com.project.customer.serviceImpl;
import com.project.customer.dto.CartDto;
import com.project.customer.repositories.CustomerRepository;
import com.project.customer.repositories.ProductRepository;
import  com.project.customer.service.CartItemServices;
import org.springframework.beans.factory.annotation.Autowired;

public class CartItemServicesImpl implements CartItemServices {


}
