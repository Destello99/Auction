//package com.project.customer.service;
//
//import org.springframework.stereotype.Service;
//
//@Service
//public interface AuctionService {
//    public void startAuction();
//}