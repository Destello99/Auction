package com.project.customer.dto;

import lombok.Data;

@Data
public class RolesDto {
    private String name;
}
