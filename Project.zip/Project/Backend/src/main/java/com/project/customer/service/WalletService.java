package com.project.customer.service;

public interface WalletService {

}
